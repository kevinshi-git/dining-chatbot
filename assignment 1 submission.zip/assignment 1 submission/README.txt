url:
http://kevinshihw1cloud.s3-website-us-east-1.amazonaws.com